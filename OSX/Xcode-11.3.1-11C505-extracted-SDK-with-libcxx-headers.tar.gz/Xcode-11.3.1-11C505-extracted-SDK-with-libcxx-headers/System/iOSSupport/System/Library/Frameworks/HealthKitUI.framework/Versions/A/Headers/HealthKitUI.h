//
//  HealthKitUI.h
//  HealthKitUI
//
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <HealthKitUI/HKActivityRingView.h>
