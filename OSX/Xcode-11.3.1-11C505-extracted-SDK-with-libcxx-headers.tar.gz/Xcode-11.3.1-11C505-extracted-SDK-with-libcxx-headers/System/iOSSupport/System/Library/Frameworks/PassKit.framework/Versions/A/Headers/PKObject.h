//
//  PKObject.h
//  PassKit
//
//  Copyright (c) 2013 Apple, Inc. All rights reserved.
//

#ifndef __PKOBJECT_H
#define __PKOBJECT_H

#import <Foundation/Foundation.h>
#import <PassKit/PKError.h>

@interface PKObject : NSObject

@end

#endif // __PKOBJECT_H
