//
//  SFFoundation.h
//  SafariServices
//
//  Copyright © 2015 Apple Inc. All rights reserved.
//

#ifdef __cplusplus
#define SF_EXTERN extern "C" __attribute__((visibility ("default")))
#else
#define SF_EXTERN extern __attribute__((visibility ("default")))
#endif
