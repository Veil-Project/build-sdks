//
//  PHEditingExtensionContext.h
//  PhotosUI
//
//  Copyright (c) 2014 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


OS_EXPORT API_DEPRECATED("No longer supported. This class will be removed in an upcoming release.", ios(8, 13)) API_UNAVAILABLE(macCatalyst)

@interface PHEditingExtensionContext : NSExtensionContext

@end
