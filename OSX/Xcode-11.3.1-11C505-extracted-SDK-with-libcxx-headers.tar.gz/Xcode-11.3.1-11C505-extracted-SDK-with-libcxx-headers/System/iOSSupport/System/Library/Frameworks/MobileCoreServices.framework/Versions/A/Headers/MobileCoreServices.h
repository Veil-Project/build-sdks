/*
	File:      MobileCoreServices/MobileCoreServices.h
 
	Contains:  Master include for MobileCoreServices
 
	Copyright: (c) 1999-2018 Apple Inc. All rights reserved. 
 */

#import <CoreServices/CoreServices.h>
